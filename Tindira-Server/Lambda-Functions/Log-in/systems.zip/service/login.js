const AWS = require("aws-sdk");
const axios = require("axios");
const bcrypt = require("bcryptjs");
const util = require("../utils/util");
const auth = require("../utils/auth");

AWS.config.update({
  region: "us-east-2",
});

const dynamoDB = new AWS.DynamoDB.DocumentClient();
const userTable = "TindiraUsers";
const getUserByUserNameEndpoint =
  "https://aa94or46cc.execute-api.us-east-2.amazonaws.com/prod/user";

// Define the API key directly
const X_API_KEY = "ncVT79MBOfag9tx2Cr2RT7BmhydcTjyUaDgwhfQ6";

async function login(user) {
  const username = user.username;
  const password = user.password;

  if (!user || !username || !password) {
    return util.buildResponse(401, {
      message: "username and password are required",
    });
  }

  const dynamoUser = await getUser(username.toLowerCase().trim());
  if (!dynamoUser || !dynamoUser.username) {
    return util.buildResponse(403, {
      message: "user doesn't exist",
    });
  }

  if (!bcrypt.compareSync(password, dynamoUser.password)) {
    return util.buildResponse(403, {
      message: "Password is incorrect",
    });
  }

  // Call the external Lambda function after successful login
  try {
    const externalUser = await getUserFromExternalService(username);
    const userInfo = {
      username: externalUser.username,
      fullName: externalUser.fullName,
      profilePicture: externalUser.profilePicture,
      profileDescription: externalUser.profileDescription,
    };
    const token = auth.generateToken(userInfo);
    const response = {
      user: userInfo,
      token: token,
    };
    return util.buildResponse(200, response);
  } catch (error) {
    console.error(
      "Error calling external service: ",
      error.response ? error.response.data : error.message
    );
    return util.buildResponse(500, {
      message: "An error occurred while fetching user details",
    });
  }
}

async function getUser(username) {
  const params = {
    TableName: userTable,
    Key: {
      username: username,
    },
  };
  return await dynamoDB
    .get(params)
    .promise()
    .then(
      (response) => response.Item,
      (error) => {
        console.error("There is an error getting user: ", error);
      }
    );
}

async function getUserFromExternalService(username) {
  // Define the additional query parameters
  const fields = "username,firstName,history";
  const url = `${getUserByUserNameEndpoint}?username=${username}&fields=${fields}`;

  try {
    const response = await axios.get(url, {
      headers: {
        "x-api-key": X_API_KEY,
        "Content-Type": "application/json",
      },
    });
    console.log("External service response: ", response.data); // Detailed logging
    return response.data;
  } catch (error) {
    console.error(
      "Axios error: ",
      error.response ? error.response.data : error.message,
      "Axios full error: ",
      error // Log full Axios error
    );
    throw error;
  }
}

module.exports.login = login;
